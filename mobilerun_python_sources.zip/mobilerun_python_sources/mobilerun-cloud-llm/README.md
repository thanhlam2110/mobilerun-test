# mobilerun-cloud-llm

Python SDK example for running MobileRun with OpenAI API through the `OpenAIResponses` provider.

## Setup

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
pip install -r requirements.txt
```

Prepare the Android device:

```powershell
adb devices
mobilerun setup
mobilerun ping
```

Set OpenAI API key:

```powershell
$env:OPENAI_API_KEY="YOUR_OPENAI_API_KEY"
```

## Run

```powershell
python app.py --goal "Open Settings and tell me the Android version" --steps 20 --debug
```

Equivalent explicit CLI command that was tested:

```powershell
mobilerun run "Open Settings and tell me the Android version" --provider OpenAIResponses --model gpt-4o --steps 20 --debug
```

## Useful options

```powershell
python app.py --goal "Open Settings and tell me the Android version" --steps 20 --debug
python app.py --goal "Open Settings and tell me the Android version" --steps 30 --reasoning --debug
python app.py --goal "Open Settings and tell me the Android version" --steps 30 --vision --debug
python app.py --goal "Open Settings and tell me the Android version" --device YOUR_DEVICE_SERIAL --steps 20 --debug
```
